Some useful scripts to playback and modify the produced ros-bag files.

These are usually saved to:
/home/<user>/.ros/towr_trajectory.bag
